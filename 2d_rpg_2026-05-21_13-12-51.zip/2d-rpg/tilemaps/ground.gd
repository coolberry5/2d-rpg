class_name Ground extends Node2D

@onready var detection_box : DetectionBox = $DetectionBox
@onready var hills : TileMapLayer = $hills


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	hills.z_index = 0
	detection_box.player_detected.connect( player_detected )
	detection_box.player_undetected.connect( player_undetected )
	pass


func player_undetected() -> void:
	hills.z_index = 0
	pass

func player_detected() -> void:
	hills.z_index = -1
	pass
