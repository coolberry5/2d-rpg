class_name tree extends Node2D

@onready var animation_player : AnimationPlayer = $AnimationPlayer
var cutdown : bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$HitBox.Damaged.connect( TakeDamage )
	pass # Replace with function body.


func TakeDamage( _damage : int ) -> void:
	if cutdown == false:
		animation_player.play("tree_fall")
		cutdown = true
	else:
		pass
