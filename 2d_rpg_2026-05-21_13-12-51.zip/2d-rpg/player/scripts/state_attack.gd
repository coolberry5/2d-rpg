class_name State_Attack extends State

var attacking : bool = false
@onready var walk : State = $"../walk"
@onready var idle : State = $"../idle"
@onready var hurt_box : HurtBox = $"../../Interactions/HurtBox"

@onready var animaton_player : AnimationPlayer = $"../../AnimationPlayer"
@export var attack_sound : AudioStream
@onready var audio : AudioStreamPlayer2D = $"../../audio/AudioStreamPlayer2D"

@export_range(1,20,0.5) var decelerate_speed : float
#what happens when the player enters the state
func Enter() -> void:
	player.UpdateAnimation("attack")
	animaton_player.animation_finished.connect( EndAttack )
	
	audio.stream = attack_sound
	audio.pitch_scale = randf_range( 0.9, 1.1 )
	audio.play()
	
	attacking = true
	
	hurt_box.monitoring = true
	pass

#what happens when the player exits the state
func Exit() -> void:
	animaton_player.animation_finished.disconnect( EndAttack )
	
	attacking = false
	
	hurt_box.monitoring = false
	pass

#what happens during the process update in this state
func Process( _delta : float) -> State:
	player.velocity -= player.velocity * decelerate_speed * _delta
	
	if attacking == false:
		if player.direction == Vector2.ZERO:
			return idle
		else:
			return walk
	return null

#what happens durning the physics process update
func Physics(delta: float) -> State:
	return null

#what happens withinput events in this state
func HandleInput( _event: InputEvent) -> State:
	return null


func EndAttack( _newAnimName : String ) -> void:
	attacking = false
