class_name State extends Node

#stores refernce to the player that this state belongs to#
static var player : Player


#what happens when the player enters the state
func Enter() -> void:
	pass

#what happens when the player exits the state
func Exit() -> void:
	pass

#what happens during the process update in this state
func Process( _delta : float) -> State:
	return null

#what happens durning the physics process update
func Physics(delta: float) -> State:
	return null

#what happens withinput events in this state
func HandleInput( _event: InputEvent) -> State:
	return null
