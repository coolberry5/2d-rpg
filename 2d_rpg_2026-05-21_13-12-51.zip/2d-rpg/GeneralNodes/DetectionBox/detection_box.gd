class_name DetectionBox extends Area2D

signal player_detected()
signal player_undetected()
signal enemy_detected()
signal enemy_undetected()


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	body_entered.connect( _body_detected )
	body_exited.connect( _body_undetected )
	pass # Replace with function body.


func _body_detected( b : Node2D ) -> void:
	if b is Player:
		player_detected.emit()
	if b is Enemy:
		enemy_detected.emit()
	pass


func _body_undetected( b : Node2D ) -> void:
	if b is Player:
		player_undetected.emit()
	if b is Enemy:
		enemy_undetected.emit()
	pass
